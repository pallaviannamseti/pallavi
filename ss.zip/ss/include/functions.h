// function declaration
void init();
void updateMetaData();

void customerEdit();
void customerAdd();
void customerDelete();
void customerUpdate();

void BookingsEdit();
void BookingsAdd();
void BookingsDelete();
void BookingsUpdate();

void CheckInOutEdit();
void CheckInOutAdd();
void CheckInOutDelete();


void readMetaData();
void updateMetaData();
void readCustomers();
void updateCustomers();
void readRooms();
void updateRooms();
void readBookings();
void updateBookings();
void readBills();
void updateBills();
void readChecks();
void updateChecks();

void showRoomAvailable();
void generateBill();

void generateRoomsData();